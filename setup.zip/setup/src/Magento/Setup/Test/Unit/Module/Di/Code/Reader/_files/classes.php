<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

// @codingStandardsIgnoreStart
namespace My\NamespaceA;

interface InterfaceA
{
}

class ClassA
{
}

namespace My\NamespaceB;

interface InterfaceB
{
}

class ClassB
{
}
